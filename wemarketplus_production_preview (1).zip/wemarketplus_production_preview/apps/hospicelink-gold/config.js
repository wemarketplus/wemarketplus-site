window.HLM_CONFIG = {
  API_BASE: "https://YOUR-BACKEND-URL.onrender.com"
};
