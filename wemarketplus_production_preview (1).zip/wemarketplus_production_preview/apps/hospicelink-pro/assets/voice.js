
function startVoice(){
  if (!('webkitSpeechRecognition' in window)) {
    alert('Voice not supported on this browser');
    return;
  }
  const recognition = new webkitSpeechRecognition();
  recognition.lang = 'en-US';
  recognition.start();
  recognition.onresult = function(event){
    const transcript = event.results[0][0].transcript;
    document.getElementById('notes').value += transcript + "\n";
  };
}
