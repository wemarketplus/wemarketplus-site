
async function askAI(prompt){
  const res = await fetch('/api/ai', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({prompt})
  });
  const data = await res.json();
  return data.text || 'No response';
}

async function generateMessage(){
  const context = document.getElementById('context').value;
  const text = await askAI("Create a compassionate hospice outreach message: " + context);
  document.getElementById('output').value = text;
}
