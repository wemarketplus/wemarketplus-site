We Market Plus LLC - Production Starter

What this package contains:
- /site : customer-facing website preview with all requested pages
- /backend : Flask starter backend copied from the HospiceLink Max SaaS package
- /apps/hospicelink-pro : uploaded HospiceLink Pro files
- /apps/hospicelink-max : uploaded HospiceLink Max frontend files
- /apps/hospicelink-gold : starter copy for HospiceLink Gold

What is production-ready versus preview-only:
- The public website pages are preview-ready and deployable as static pages.
- The backend includes a real starter for login/register/session handling and Stripe checkout session creation.
- You still must add your real secrets before launch:
  STRIPE_SECRET_KEY
  STRIPE_WEBHOOK_SECRET
  STRIPE_PRICE_STARTER
  STRIPE_PRICE_GROWTH
  STRIPE_PRICE_ENTERPRISE
  FLASK_SECRET_KEY
  CORS_ORIGINS
  APP_BASE_URL

What I could not do here:
- I could not publish to your real domain or connect DNS.
- I could not activate Stripe without your account keys and price IDs.
- I could not make login fully live without deploying the backend and setting secure production secrets.
