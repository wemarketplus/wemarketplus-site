# HospiceLink Max SaaS Starter

## Included
- marketing website
- login/signup frontend
- Flask backend starter
- agency registration
- session auth
- Stripe checkout scaffolding
- Stripe webhook scaffolding
- subscription status field
- seeded demo user

## Demo login
- owner@demoagency.com
- demo123

## Local run
1. Create a virtual environment
2. Install requirements: `pip install -r requirements.txt`
3. Copy `.env.example` to `.env`
4. Run: `python app.py`
5. Open `http://127.0.0.1:8787`

## Important
This is a commercial starter package, not a completed HIPAA-certified deployment.
Before selling publicly, finish production auth hardening, HTTPS, database backups, audit logging, legal review, and HIPAA-aligned hosting.
