import os, sqlite3
from datetime import datetime
from pathlib import Path
from functools import wraps
from flask import Flask, jsonify, request, session, send_from_directory
from dotenv import load_dotenv
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
try:
    import stripe
except Exception:
    stripe=None
BASE_DIR=Path(__file__).resolve().parent
load_dotenv(BASE_DIR / '.env')
DB_PATH=BASE_DIR/'hospicelinkmax.db'
app=Flask(__name__, static_folder='../frontend', static_url_path='/')
app.secret_key=os.getenv('FLASK_SECRET_KEY','change-me-in-production')
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax')
CORS(app,supports_credentials=True,origins=os.getenv('CORS_ORIGINS','*').split(','))
STRIPE_SECRET_KEY=os.getenv('STRIPE_SECRET_KEY','')
STRIPE_WEBHOOK_SECRET=os.getenv('STRIPE_WEBHOOK_SECRET','')
STRIPE_PRICE_STARTER=os.getenv('STRIPE_PRICE_STARTER','price_starter_placeholder')
STRIPE_PRICE_GROWTH=os.getenv('STRIPE_PRICE_GROWTH','price_growth_placeholder')
STRIPE_PRICE_ENTERPRISE=os.getenv('STRIPE_PRICE_ENTERPRISE','price_enterprise_placeholder')
APP_BASE_URL=os.getenv('APP_BASE_URL','http://127.0.0.1:8787')
if stripe and STRIPE_SECRET_KEY: stripe.api_key=STRIPE_SECRET_KEY

def db():
    conn=sqlite3.connect(DB_PATH); conn.row_factory=sqlite3.Row; return conn

def init_db():
    conn=db(); cur=conn.cursor()
    cur.execute('CREATE TABLE IF NOT EXISTS agencies (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, plan TEXT NOT NULL DEFAULT \'starter\', subscription_status TEXT NOT NULL DEFAULT \'active\', stripe_customer_id TEXT, created_at TEXT NOT NULL)')
    cur.execute('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, agency_id INTEGER NOT NULL, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT \'owner\', created_at TEXT NOT NULL, FOREIGN KEY (agency_id) REFERENCES agencies(id))')
    conn.commit()
    if not cur.execute('SELECT id FROM agencies WHERE name=?',('Demo Agency',)).fetchone():
        cur.execute('INSERT INTO agencies (name,plan,subscription_status,created_at) VALUES (?,?,?,?)',('Demo Agency','growth','active',datetime.utcnow().isoformat()))
        agency_id=cur.lastrowid
        cur.execute('INSERT INTO users (agency_id,name,email,password_hash,role,created_at) VALUES (?,?,?,?,?,?)',(agency_id,'Demo Owner','owner@demoagency.com',generate_password_hash('demo123'),'owner',datetime.utcnow().isoformat()))
        conn.commit()
    conn.close()

def current_user():
    uid=session.get('user_id')
    if not uid: return None
    conn=db(); row=conn.execute('SELECT users.id, users.name, users.email, users.role, agencies.name as agency_name, agencies.plan, agencies.subscription_status, agencies.id as agency_id FROM users JOIN agencies ON agencies.id=users.agency_id WHERE users.id=?',(uid,)).fetchone(); conn.close(); return row

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        user=current_user()
        if not user: return jsonify({'error':'Unauthorized'}),401
        return fn(user,*args,**kwargs)
    return wrapper
@app.route('/')
def home(): return send_from_directory(app.static_folder,'index.html')
@app.route('/demo')
def demo(): return send_from_directory(app.static_folder,'demo.html')
@app.route('/api/register',methods=['POST'])
def register():
    data=request.get_json(force=True)
    req=['agency_name','owner_name','email','password','plan']
    if not all(data.get(k) for k in req): return jsonify({'error':'Missing required fields'}),400
    agency_name=data['agency_name'].strip(); owner_name=data['owner_name'].strip(); email=data['email'].strip().lower(); password=data['password']; plan=data['plan'].strip().lower()
    conn=db(); cur=conn.cursor()
    if cur.execute('SELECT id FROM users WHERE email=?',(email,)).fetchone(): conn.close(); return jsonify({'error':'Email already in use'}),400
    cur.execute('INSERT INTO agencies (name,plan,subscription_status,created_at) VALUES (?,?,?,?)',(agency_name,plan,'trial',datetime.utcnow().isoformat())); agency_id=cur.lastrowid
    cur.execute('INSERT INTO users (agency_id,name,email,password_hash,role,created_at) VALUES (?,?,?,?,?,?)',(agency_id,owner_name,email,generate_password_hash(password),'owner',datetime.utcnow().isoformat())); conn.commit(); conn.close(); return jsonify({'message':'Agency created'}),201
@app.route('/api/login',methods=['POST'])
def login():
    data=request.get_json(force=True); email=data.get('email','').strip().lower(); password=data.get('password','')
    conn=db(); row=conn.execute('SELECT users.id, users.name, users.email, users.password_hash, users.role, agencies.name as agency_name, agencies.plan, agencies.subscription_status FROM users JOIN agencies ON agencies.id=users.agency_id WHERE users.email=?',(email,)).fetchone(); conn.close()
    if not row or not check_password_hash(row['password_hash'],password): return jsonify({'error':'Invalid email or password'}),401
    session['user_id']=row['id']
    return jsonify({'id':row['id'],'name':row['name'],'email':row['email'],'role':row['role'],'agency_name':row['agency_name'],'plan':row['plan'],'subscription_status':row['subscription_status']})
@app.route('/api/logout',methods=['POST'])
def logout(): session.clear(); return jsonify({'message':'Logged out'})
@app.route('/api/me')
@login_required
def me(user): return jsonify({'id':user['id'],'name':user['name'],'email':user['email'],'role':user['role'],'agency_name':user['agency_name'],'plan':user['plan'],'subscription_status':user['subscription_status']})
@app.route('/api/stripe/create-checkout-session',methods=['POST'])
@login_required
def checkout(user):
    if not stripe or not STRIPE_SECRET_KEY: return jsonify({'error':'Stripe is not configured','hint':'Set STRIPE_SECRET_KEY and price IDs.'}),400
    data=request.get_json(force=True) if request.data else {}
    plan=(data.get('plan') or user['plan']).lower(); price_map={'starter':STRIPE_PRICE_STARTER,'growth':STRIPE_PRICE_GROWTH,'enterprise':STRIPE_PRICE_ENTERPRISE}; price_id=price_map.get(plan,STRIPE_PRICE_GROWTH)
    sess=stripe.checkout.Session.create(mode='subscription',line_items=[{'price':price_id,'quantity':1}],success_url=f'{APP_BASE_URL}/?checkout=success',cancel_url=f'{APP_BASE_URL}/?checkout=cancelled',client_reference_id=str(user['agency_id']),customer_email=user['email'],metadata={'agency_id':str(user['agency_id']),'plan':plan})
    return jsonify({'url':sess.url})
@app.route('/api/stripe/webhook',methods=['POST'])
def webhook():
    if not stripe or not STRIPE_SECRET_KEY or not STRIPE_WEBHOOK_SECRET: return jsonify({'error':'Stripe webhook not configured'}),400
    payload=request.data; sig=request.headers.get('Stripe-Signature')
    try: event=stripe.Webhook.construct_event(payload,sig,STRIPE_WEBHOOK_SECRET)
    except Exception as ex: return jsonify({'error':f'Webhook verification failed: {ex}'}),400
    et=event['type']; obj=event['data']['object']; metadata=obj.get('metadata') or {}; agency_id=metadata.get('agency_id') or obj.get('client_reference_id')
    if agency_id:
        conn=db()
        if et in ['checkout.session.completed','customer.subscription.updated','customer.subscription.created']: conn.execute('UPDATE agencies SET subscription_status=? WHERE id=?',('active',agency_id))
        if et in ['invoice.payment_failed','customer.subscription.deleted']: conn.execute('UPDATE agencies SET subscription_status=? WHERE id=?',('past_due',agency_id))
        conn.commit(); conn.close()
    return jsonify({'received':True})
@app.route('/health')
def health(): return jsonify({'ok':True,'service':'HospiceLink Max SaaS starter'})
if __name__=='__main__': init_db(); app.run(host='0.0.0.0',port=8787,debug=True)
