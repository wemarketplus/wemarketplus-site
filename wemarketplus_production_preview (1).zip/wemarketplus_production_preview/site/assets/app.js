
document.querySelectorAll('[data-plan]').forEach(btn=>{btn.addEventListener('click',e=>{e.preventDefault();const plan=btn.getAttribute('data-plan');alert(`This is the ${plan} checkout button preview. When Stripe is connected, this will open secure checkout.`)})})
document.querySelectorAll('[data-demo-submit]').forEach(form=>form.addEventListener('submit',e=>{e.preventDefault();alert('Demo request preview submitted. Connect this form to your calendar or CRM inbox when you go live.') }))
document.querySelectorAll('[data-auth-submit]').forEach(form=>form.addEventListener('submit',e=>{e.preventDefault();alert('Login / signup preview only. Connect this page to your production auth backend to make it live.') }))
document.querySelectorAll('[data-contact-submit]').forEach(form=>form.addEventListener('submit',e=>{e.preventDefault();alert('Message preview only. Connect to email or backend when ready.') }))
